<?php

namespace DeliciousBrains\WPMDB\Common\Cli;

class CliManager {
	//Silence is golden.
}
