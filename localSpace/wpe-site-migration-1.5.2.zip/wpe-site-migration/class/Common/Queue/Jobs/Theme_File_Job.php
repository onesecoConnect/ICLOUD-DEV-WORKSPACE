<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Jobs;

class Theme_File_Job extends File_Job {
}
