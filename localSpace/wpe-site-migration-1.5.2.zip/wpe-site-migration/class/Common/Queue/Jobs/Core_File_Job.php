<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Jobs;

class Core_File_Job extends File_Job {
}
