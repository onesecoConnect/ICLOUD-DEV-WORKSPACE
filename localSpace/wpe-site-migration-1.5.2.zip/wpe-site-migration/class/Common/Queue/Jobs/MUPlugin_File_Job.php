<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Jobs;

class MUPlugin_File_Job extends File_Job {
}
