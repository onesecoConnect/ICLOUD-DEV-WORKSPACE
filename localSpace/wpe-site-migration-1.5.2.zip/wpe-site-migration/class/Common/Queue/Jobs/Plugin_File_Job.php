<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Jobs;

class Plugin_File_Job extends File_Job {
}
