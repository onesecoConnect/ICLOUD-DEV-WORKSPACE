<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Jobs;

class Root_File_Job extends File_Job {
}
