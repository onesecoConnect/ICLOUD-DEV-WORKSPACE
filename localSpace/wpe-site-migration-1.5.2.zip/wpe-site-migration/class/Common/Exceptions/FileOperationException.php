<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

class FileOperationException extends \Exception {
}
