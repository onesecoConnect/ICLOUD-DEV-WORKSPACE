<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

use UnexpectedValueException;

class UnknownTransportMethod extends UnexpectedValueException {
}
