<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

use UnexpectedValueException;

class UnknownStateProperty extends UnexpectedValueException {
}
