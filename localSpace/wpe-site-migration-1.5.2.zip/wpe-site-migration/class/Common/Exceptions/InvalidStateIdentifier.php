<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

use UnexpectedValueException;

class InvalidStateIdentifier extends UnexpectedValueException {
}
