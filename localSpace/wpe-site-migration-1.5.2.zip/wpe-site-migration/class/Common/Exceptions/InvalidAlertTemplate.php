<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

use UnexpectedValueException;

class InvalidAlertTemplate extends UnexpectedValueException {
}
