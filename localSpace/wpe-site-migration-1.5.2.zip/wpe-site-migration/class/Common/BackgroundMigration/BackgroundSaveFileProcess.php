<?php

namespace DeliciousBrains\WPMDB\Common\BackgroundMigration;

class BackgroundSaveFileProcess extends BackgroundMigrationProcess {
	/**
	 * @inheritdoc
	 */
	protected $action = 'savefile';
}
