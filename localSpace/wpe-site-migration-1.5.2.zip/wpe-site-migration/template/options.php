<?php defined( 'ABSPATH' ) || exit; ?>

<div class="wrap wpmdb">
	<div id="wpmdb-main">
		<?php
		do_action( 'wpmdb_notices' );
		?>
		<!-- React mounts here -->
		<div id="root"></div>
	</div>
	<!-- end #wpmdb-main -->
</div> <!-- end .wrap -->
