<?php

$GLOBALS['wpmdb_meta']['wpe-site-migration']['version'] = '1.5.2';
